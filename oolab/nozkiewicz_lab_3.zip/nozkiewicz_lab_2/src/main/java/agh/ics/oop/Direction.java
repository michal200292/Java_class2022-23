package agh.ics.oop;

public enum Direction {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT,

}
